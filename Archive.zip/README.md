# Watchfilmy — Modern Rebuild

A modern Next.js 16 rebuild of [watchfilmy.to](https://www.watchfilmy.to), reverse-engineered
into a clean, fast, accessible stack.

## Stack

- **Framework**: Next.js 16 (App Router, React 19, Turbopack)
- **Styling**: Tailwind CSS v4 (CSS-first config, dark/light theme via `data-theme`)
- **Icons**: Lucide React
- **Fonts**: Oxygen + Encode Sans Condensed (Google Fonts)
- **Language**: TypeScript (strict)

## Features

- Home page with "Featured Movies" + "Recently Added" grids
- Category archive pages with pagination
- Single movie page with embedded player, report-broken-video form, comments
- Search by movie name
- Dark / light theme toggle (persisted)
- Responsive: mobile menu, responsive grids (2→3→4→5 columns)
- SEO: per-page metadata via `generateMetadata`

## Run

```bash
npm install
npm run dev      # http://localhost:3200
npm run build
npm run start
```

## Project layout

```
src/
  app/
    page.tsx                # Home
    layout.tsx              # Root layout + fonts + theme provider
    globals.css             # Design tokens + components
    [slug]/page.tsx         # Single movie
    category/[slug]/page.tsx # Category archive
    search/page.tsx         # Search results
    login/page.tsx          # Sign in
    not-found.tsx
  components/
    Header, Footer, MovieCard, MovieGrid, SectionHeading,
    Pagination, VideoPlayer, ReportForm, CommentSection,
    Sidebar, ThemeProvider
  lib/
    types.ts                # Movie, Category types
    data.ts                 # Mock catalog + helpers
```

## Notes

- The catalog in `src/lib/data.ts` is mock data mirroring the original site's structure.
  Replace with a real data source (Postgres + Prisma, or headless WordPress) for production.
- Video delivery uses an iframe embed. For a real product, swap in a licensed CDN
  (Mux, Cloudflare Stream) with HLS.js.
- Images are remote (original CDN). Configure `next.config.ts` image domains as needed.

## ⚠️ Copyright

The original site distributes copyrighted Indian films. This rebuild is provided for
educational/structural purposes. Only use with licensed or your own content.
